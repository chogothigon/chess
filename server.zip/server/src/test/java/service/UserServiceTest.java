package service;

import dataaccess.*;
import model.*;
import org.junit.jupiter.api.BeforeEach;
import org.mindrot.jbcrypt.BCrypt;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserServiceTest {
    private final UserDAO userDAO = new MemoryUserDAO();
    private final AuthDAO authDAO = new MemoryAuthDAO();
    private final UserService service = new UserService(userDAO, authDAO);

    @BeforeEach
    void clear() throws DataAccessException {
        userDAO.clear();
        authDAO.clear();
    }

    @Test
    void register() throws DataAccessException, ResponseException {
        var user = new UserData("ryan", "password", "test@gmail.com");
        var result = service.register(user);
        var storedUser = userDAO.getUser("ryan");

        assertEquals(user.username(), storedUser.username());
        assertEquals(user.email(), storedUser.email());
        assertNotEquals(user.password(), storedUser.password());
        assertTrue(BCrypt.checkpw(user.password(), storedUser.password()));
    }

    @Test
    void registerDuplicate() throws DataAccessException, ResponseException {
        var user = new UserData("ryan", "password", "test@gmail.com");
        service.register(user);

        var exception = assertThrows(ResponseException.class,
                () -> service.register(user));

        assertEquals(403, exception.toHttpStatusCode());
    }

    @Test
    void registerMissingUsername() {
        var user = new UserData(null, "password", "test@gmail.com");

        var exception = assertThrows(ResponseException.class,
                () -> service.register(user));

        assertEquals(400, exception.toHttpStatusCode());
    }

    @Test
    void login() throws DataAccessException, ResponseException {
        String hashedPassword = BCrypt.hashpw("password", BCrypt.gensalt());
        userDAO.createUser(new UserData("ryan", hashedPassword, "test@gmail.com"));

        var user = new UserData("ryan", "password", null);
        var result = service.login(user);

        assertEquals("ryan", result.username());
        assertNotNull(result.authToken());
        assertEquals(result, authDAO.getAuth(result.authToken()));
    }

    @Test
    void loginWrongPassword() throws DataAccessException {
        String hashedPassword = BCrypt.hashpw("password", BCrypt.gensalt());
        userDAO.createUser(new UserData("ryan", hashedPassword, "test@gmail.com"));

        var user = new UserData("ryan", "wrongpassword", null);

        var exception = assertThrows(ResponseException.class,
                () -> service.login(user));

        assertEquals(401, exception.toHttpStatusCode());
    }

    @Test
    void loginInvalidUser() {
        var user = new UserData("unknown", "password", null);

        var exception = assertThrows(ResponseException.class,
                () -> service.login(user));

        assertEquals(401, exception.toHttpStatusCode());
    }

    @Test
    void loginMissingPassword() {
        var user = new UserData("ryan", null, null);

        var exception = assertThrows(ResponseException.class,
                () -> service.login(user));

        assertEquals(400, exception.toHttpStatusCode());
    }

    @Test
    void logout() throws DataAccessException, ResponseException {
        var user = new UserData("ryan", "password", "test@email.com");
        var auth = service.register(user);

        service.logout(auth.authToken());

        assertNull(authDAO.getAuth(auth.authToken()));
    }

    @Test
    void logoutInvalidToken() {
        var exception = assertThrows(ResponseException.class,
                () -> service.logout("invalidToken"));

        assertEquals(401, exception.toHttpStatusCode());
    }

    @Test
    void logoutMissingToken() {
        var exception = assertThrows(ResponseException.class,
                () -> service.logout(null));

        assertEquals(401, exception.toHttpStatusCode());
    }
}
